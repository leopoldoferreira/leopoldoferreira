#include <stdio.h>

int main()
{
    int num, soma=0;
    do
    {
        printf("\nDigite um valor (0 para sair): ");
        scanf("%d",&num);
        if(num>0)
            soma=soma+num;

    }while(num!=0);
    printf("\n\nA soma dos inteiros positivos e %d",soma);

    return 0;
}
