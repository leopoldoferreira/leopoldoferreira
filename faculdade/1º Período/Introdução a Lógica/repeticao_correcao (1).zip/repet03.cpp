#include <stdio.h>

int main()
{
    float maria=1.57,joao=1.45;
    int ano=0;
    printf("\tAno\tJoao\tMaria");
    printf("\n\t%02d\t%.2f\t%.2f",ano,joao,maria);
    while(joao<maria)
    {
        joao=joao+0.23;
        maria=maria+0.15;
        ano++;
        printf("\n\t%02d\t%.2f\t%.2f",ano,joao,maria);
    }

    return 0;
}
