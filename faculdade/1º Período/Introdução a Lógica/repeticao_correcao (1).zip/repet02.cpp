#include <stdio.h>

int main()
{
    int num, cont;

    printf("Informe o numero para calculo da tabuada: ");
    scanf("%d",&num);
    printf("\n\t\tTABUADA DO %d\n\n",num);
    for(cont=1;cont<=10;cont++)
    {
        printf("\n\t%02d \t* \t%02d \t= \t%02d",num,cont,num*cont);
    }
    printf("\n\n\n");
    return 0;
}
