#include <stdio.h>

int main()
{
    int tanq,km=0;
    printf("\tLitros\tKms");
    for(tanq=45;tanq>=0;tanq--)
    {
        printf("\n\t%02dl\t%04dkm",tanq,km);
        km=km+12;
    }
    return 0;
}
